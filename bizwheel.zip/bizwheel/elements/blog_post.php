<?php
add_shortcode('blog','blog_client_group');
function blog_client_group($something){
$result = shortcode_atts(array(
        'count' => '',
),$something);
extract($result);
ob_start();
?>


		<!-- Latest Blog -->
		<section class="latest-blog section-space">
			<div class="container">
				<div class="row">
					<div class="col-12">
						<div class="blog-latest blog-latest-slider">
							
								<?php
								$sd = new WP_Query(array(
									'post_type'   => 'post',
									'posts_per_page'   => $count,
								));
								while ($sd->have_posts()):$sd->the_post();
								?>
							<div class="single-slider">
								<!-- Single Blog -->
								<div class="single-news ">
									<div class="news-head overlay">
										<span class="news-img"><?php the_post_thumbnail(); ?></span>
										<a href="<?php the_permalink(); ?>" class="bizwheel-btn theme-2"><?php esc_html_e('Read More', 'bizwheel'); ?></a>
									</div>
									<div class="news-body">
										<div class="news-content">
											<h3 class="news-title"><a href="<?php the_permalink(); ?>"><?php the_title();?></a></h3>
											<div class="news-text"><p><?php echo wp_trim_words(get_the_content(),25, ' ')?></p></div>
											<ul class="news-meta">
												<li class="date"><i class="fa fa-calendar"></i><?php the_time('j M Y') ?></li>
												<li class="view"><i class="fa fa-comments"></i><?php comments_popup_link('No Comment',' 1 Comment','% Comment');?></li>
											</ul>
										</div>
									</div>
								</div>
								<!--/ End Single Blog -->
							</div>
							<?php endwhile; ?>
							
						</div>
					</div>
				</div>
			</div>
		</section>
		<!--/ End Latest Blog -->
		
	
<?php
return ob_get_clean();
}

add_action( 'vc_before_init', 'group_feeds_elmentors' );
function group_feeds_elmentors() {
 vc_map( array(
  "name" => __( "Style Blog Post", "bizwheel" ),
  "base" => "blog",
  "category" => __( "Bizwheel", "bizwheel"),

  "params" => array(
 array(
  "type" => "textfield",
  "heading" => __( "Post Count", "bizwheel" ),
  "param_name" => "count",
),
  )
 ) );
}

?>




