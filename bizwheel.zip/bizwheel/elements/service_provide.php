<?php
add_shortcode('post_count','latestnews_section_function');
function latestnews_section_function($something){
$result = shortcode_atts(array(
        'count' => '',
		'icon' => '',
),$something);
extract($result);
ob_start();
?>


		<!-- Services -->
		<section class="services section-bg">
			<div class="container">
				<div class="row">
					
				<?php
				  $post = new WP_Query(array(
					'post_type'   => 'post',
					'posts_per_page'   => $count,
                    'orderby' => 'title',
                    'order'   => 'DESC',
					"category_name"  =>'design'
				  ));
				  while ($post->have_posts()):$post->the_post();
			   ?>
					<div class="col-lg-4 col-md-4 col-12">
						<!-- Single Service -->
						<div class="single-service">
							<div class="service-head">
							<?php the_post_thumbnail(); ?>
								<div class="icon-bg"><i class="<?php echo $icon;?>"></i></div>
							</div>
							<div class="service-content">
								<h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
								<p><?php echo wp_trim_words(get_the_content(), 17, ' ')?></p>
								<a class="btn" href="<?php the_permalink(); ?>"><i class="fa fa-arrow-circle-o-right"></i>View Service</a>
							</div>
						</div>
						<!--/ End Single Service -->
					</div>
				<?php endwhile; ?>
					
				</div>
			</div>
		</section>
		<!--/ End Services -->
		


<?php
return ob_get_clean();
}

add_action( 'vc_before_init', 'latest_news_section_function' );
function latest_news_section_function() {
 vc_map( array(
  "name" => __( "Service provide", "bizwheel" ),
  "base" => "post_count",
  "category" => __( "Bizwheel", "bizwheel"),

  "params" => array(
 array(
  "type" => "textfield",
  "heading" => __( "Post Count", "bizwheel" ),
  "param_name" => "count",
),
 array(
  "type" => "iconpicker",
  "heading" => __( "Set The Service Section Icon", "bizwheel" ),
  "param_name" => "icon",
),

)
 ) );
}

?>
