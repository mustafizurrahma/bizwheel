<?php
add_shortcode('blog','blog_client_group_feeds');
function blog_client_group_feeds($something){
$result = shortcode_atts(array(
        'count' => '',
),$something);
extract($result);
ob_start();
?>


	<!-- Blog Layout -->
		<section class="blog-layout news-default section-space">
			<div class="container">
				<div class="row ">
				
				<?php
				$sd = new WP_Query(array(
					'post_type'   => 'post',
				));
				while ($sd->have_posts()):$sd->the_post();
				 ?>
					<div class="col-lg-4 col-md-6 col-12">
						<!-- Single Blog -->
						<div class="single-news ">
							<div class="news-head overlay">
								<?php the_post_thumbnail(); ?>
								<ul class="news-meta">
									<li class="author"><a href="#"><i class="fa fa-user"></i>site</a></li>
									<li class="date"><i class="fa fa-calendar"></i>April 15, 2020</li>
									<li class="view"><i class="fa fa-comments"></i>0</li>
								</ul>
							</div>
							<div class="news-body">
								<div class="news-content">
									<h3 class="news-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></a></h3>
									<div class="news-text"><p><?php echo wp_trim_words(get_the_content(),14, ' ')?></p></div>
									<a href="<?php the_permalink(); ?>" class="more">Continue reading <i class="fa fa-angle-double-right" aria-hidden="true"></i></a>
								</div>
							</div>
						</div>
						<!--/ End Single Blog -->
					</div>
					
					<?php endwhile; ?>
					
				</div>
				<div class="row">
					<div class="col-12">
						<!-- Pagination -->
						<div class="pagination-plugin">
							<ul class="pagination-list">
								<?php the_posts_pagination(); ?>
							</ul>
						</div>
						<!--/ End Pagination -->
					</div>
				</div>
			</div>
		</section>
	
<?php
return ob_get_clean();
}

add_action( 'vc_before_init', 'client_group_feeds_elmentors' );
function client_group_feeds_elmentors() {
 vc_map( array(
  "name" => __( "Blog Post", "bizwheel" ),
  "base" => "blog",
  "category" => __( "Bizwheel", "bizwheel"),

  "params" => array(
 array(
  "type" => "textfield",
  "heading" => __( "Post Count", "bizwheel" ),
  "param_name" => "count",
),
  )
 ) );
}

?>




