<?php
add_shortcode('title','title_section_bizwheel_theme');
function title_section_bizwheel_theme($something){
$result = shortcode_atts(array(
        'degination' => '',
		'title' => '',
        'description' => '',
),$something);
extract($result);
ob_start();
?>

				<div class="row">
					<div class="col-lg-6 offset-lg-3 col-md-8 offset-md-2 col-12">
						<div class="section-title default text-center">
							<div class="section-top">
								<h1><span><?php echo esc_html($degination);?></span><b><?php echo esc_html($title);?></b></h1>
							</div>
							<div class="section-bottom">
								<div class="text">
									<p><?php echo esc_html($description);?></p>
								</div>
							</div>
						</div>
					</div>
				</div>

<?php
return ob_get_clean();
}

add_action( 'vc_before_init', 'title_section_bizwheel' );
function title_section_bizwheel() {
 vc_map( array(
  "name" => __( "Title & Description Center", "bizwheel" ),
  "base" => "title",
  "category" => __( "Bizwheel", "bizwheel"),

  "params" => array(
 array(
  "type" => "textfield",
  "heading" => __( "Section Desination", "bizwheel" ),
  "param_name" => "degination",
),
 array(
  "type" => "textfield",
  "heading" => __( "Section title", "bizwheel" ),
  "param_name" => "title",
),
 array(
  "type" => "textfield",
  "heading" => __( "Description", "bizwheel" ),
  "param_name" => "description",
),
  )
 ) );
}

?>
