<?php
add_shortcode('clients','happy_client_group_feeds');
function happy_client_group_feeds($something){
$result = shortcode_atts(array(
        'happy_client_group' => '',
        'has' => '',
),$something);
extract($result);
ob_start();
?>
		<!-- Features Area -->
		<section class="features-area section-bg">
			<div class="container">
				<div class="row">
				
				 <?php
        $client = vc_param_group_parse_atts($happy_client_group);
        foreach ($client as $shuv) :
         ?>
					<div class="col-lg-3 col-md-6 col-12">
						<!-- Single Feature -->
						<div class="single-feature">
							<div class="icon-head"><i class="<?php echo $shuv['custom_icon']?><?php echo $shuv['icon']?>"></i></div>
							<h4><?php echo $shuv['title']?></h4>
							<p><?php echo $shuv['descp']?></p>
						</div>
						<!--/ End Single Feature -->
					</div>
					 <?php endforeach; ?>
				</div>
			</div>
		</section>
		<!--/ End Features Area -->

<?php
return ob_get_clean();
}

add_action( 'vc_before_init', 'happy_client_group_feeds_elmentors' );
function happy_client_group_feeds_elmentors() {
 vc_map( array(
  "name" => __( "Services Section", "bizwheel" ),
  "base" => "clients",
  "category" => __( "Bizwheel", "bizwheel"),
  "params" => array(
    array(
    'type' => 'param_group',
    'param_name' => 'happy_client_group',
// Note params is mapped inside param-group:
'params' => array(
array(
 "type" => "textfield",
 "heading" => __( "Title", "bizwheel" ),
 "param_name" => "title",
),
array(
 "type" => "textfield",
 "heading" => __( "Designation", "bizwheel" ),
 "param_name" => "descp",
),

array(
 "type" => "iconpicker",
 "heading" => __( "Set Your Services Icon", "bizwheel" ),
 "param_name" => "icon",
),
array(
 "type" => "textfield",
 "heading" => __( "Custom Icon ? Please Font Awesome Icon Class type And Save ( Optional )", "bizwheel" ),
 "param_name" => "custom_icon",
),


)            )
)
) );
}

?>








