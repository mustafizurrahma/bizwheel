<?php
add_shortcode('bussness','happy_client_group_bussness');
function happy_client_group_bussness($something){
$result = shortcode_atts(array(
        'happy_client_group' => '',
),$something);
extract($result);
ob_start();
?>

		<!-- Client Area -->
		<div class="clients section-bg">
			<div class="container">
				<div class="row">
					<div class="col-12">
						<div class="partner-slider">
						<?php
							$client = vc_param_group_parse_atts($happy_client_group);
							foreach ($client as $shuv) :
							$groups = wp_get_attachment_url($shuv['img']);
						?>
							<!-- Single client -->
							<div class="single-slider">
								<div class="single-client">
									<a href="#" target="_blank"><img src="<?php echo $groups; ?>"></a>
								</div>
							</div>
							<!--/ End Single client -->
							<?php endforeach; ?>
							
						</div>
					</div>
				</div>
			</div>
		</div>
		<!--/ End Client Area -->
		
<?php
return ob_get_clean();
}

add_action( 'vc_before_init', 'bussness_group_feeds_elmentors' );
function bussness_group_feeds_elmentors() {
 vc_map( array(
  "name" => __( "Happy Bussness Partner Group", "bizwheel" ),
  "base" => "bussness",
  "category" => __( "Bizwheel", "bizwheel"),
  "params" => array(
    array(
    'type' => 'param_group',
    'param_name' => 'happy_client_group',
// Note params is mapped inside param-group:
'params' => array(
array(
'type' => 'attach_image',
'heading' => 'Image',
'param_name' => 'img',
),
)            )
)
) );
}

?>
