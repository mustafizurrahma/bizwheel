<?php
add_shortcode('contact','contact_section_elmentors');
function contact_section_elmentors($something){
$result = shortcode_atts(array(
        'contact_section_group' => '',
),$something);
extract($result);
ob_start();
?>
	
		<!-- Contact Us -->
		
			<div class="container">
				<div class="row">
					
					<div class="col-lg-7 col-md-7 col-12">
						<div class="contact-box-main m-top-30">
							<div class="contact-title">
								<h2>Contact with us</h2>
								<p>euismod eu augue. Etiam vel dui arcu. Cras varius mieros pharetra, id aliquam metus venenatis. Donec sollicit</p>
							</div>
							
							
							 <?php
								$contacts = vc_param_group_parse_atts($contact_section_group);
								foreach ($contacts as $shuv) :
							?>
							<!-- Single Contact -->
							<div class="single-contact-box">
								<div class="c-icon"><i class="<?php echo $shuv['icon']?>"></i></div>
								<div class="c-text">
									<h4><?php echo $shuv['title']?></h4>
									<p><?php echo $shuv['descp']?><br> <?php echo $shuv['second_descp']?></p>
								</div>
							</div>
							<!--/ End Single Contact -->
							<?php endforeach; ?>
							
							
							<div class="button">
								<a href="#" class="bizwheel-btn theme-1">Our Works<i class="fa fa-angle-right"></i></a>
							</div>
						</div>
					</div>
				</div>
			</div>
		<!--/ End Contact Us -->
		

<?php
return ob_get_clean();
}

add_action( 'vc_before_init', 'contact_section_elmentors_group' );
function contact_section_elmentors_group() {
 vc_map( array(
  "name" => __( "Contact Section", "bizwheel" ),
  "base" => "contact",
  "category" => __( "Bizwheel", "bizwheel"),
  "params" => array(
    array(
    'type' => 'param_group',
    'param_name' => 'contact_section_group',
// Note params is mapped inside param-group:
'params' => array(
array(
 "type" => "textfield",
 "heading" => __( "Title", "bizwheel" ),
 "param_name" => "title",
),
array(
 "type" => "textarea",
 "heading" => __( "Description", "bizwheel" ),
 "param_name" => "descp",
),
array(
 "type" => "textarea",
 "heading" => __( "Description", "bizwheel" ),
 "param_name" => "second_descp",
),

array(
 "type" => "iconpicker",
 "heading" => __( "Set Your Services Icon", "bizwheel" ),
 "param_name" => "icon",
),

)            )
)
) );
}

?>