<?php
add_shortcode('skills','skill_group_feeds');
function skill_group_feeds($something){
$result = shortcode_atts(array(
        'skill_group_section' => '',
),$something);
extract($result);
ob_start();
?>

	<!-- Skill Area -->
		<section class="skill-are" style="background-image:url('https://via.placeholder.com/1700x900')">
			<div class="container">
				<div class="row">
					<div class="col-lg-6 col-md-8 col-12">
						<div class="skill-main">	
							
							
				<?php
					$skills = vc_param_group_parse_atts($skill_group_section);
					foreach ($skills as $mr_media) :
				 ?>
							<!-- Single Skill -->
							<div class="single-skill">
								<div class="skill-info">
									<h4><?php echo $mr_media['skill_title']?></h4>
								</div>
								<div class="progress">
									<div class="progress-bar" role="progressbar" aria-valuenow="47" aria-valuemin="0" aria-valuemax="100" style="width: 70%;">
									<span class="percent"><?php echo $mr_media['word']?></span></div>
								</div>
							</div>
							<!--/ End Single Skill -->
							<?php endforeach; ?>
							
						</div>
					</div>
				</div>
			</div>
		</section>	
		<!--/ End Skill Area -->

<?php
return ob_get_clean();
}

add_action( 'vc_before_init', 'skill_group_feeds_elmentors' );
function skill_group_feeds_elmentors() {
 vc_map( array(
  "name" => __( "Skill Group", "bizwheel" ),
  "base" => "skills",
  "category" => __( "Bizwheel", "bizwheel"),
  "params" => array(
    array(
    'type' => 'param_group',
    'param_name' => 'skill_group_section',
// Note params is mapped inside param-group:
'params' => array(

array(
 "type" => "textfield",
 "heading" => __( "Skill Title", "bizwheel" ),
 "param_name" => "skill_title",
),

array(
 "type" => "textfield",
 "heading" => __( "Skill Word Count", "bizwheel" ),
 "param_name" => "word",
),
)            )
)
) );
}

?>








