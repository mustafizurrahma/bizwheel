<?php
add_shortcode('satisfied','satisfied_client_group_feeds');
function satisfied_client_group_feeds($something){
$result = shortcode_atts(array(
        'satisfied_client_group' => '',
),$something);
extract($result);
ob_start();
?>


		<!-- Testimonials -->
		<section class="testimonials section-space" style="background-image:url('https://wallpapercave.com/wp/Zh3wB84.jpg')">
			<div class="container">
				<div class="row">
					<div class="col-lg-6 col-md-9 col-12">
						<div class="section-title default text-left">
							<div class="section-top">
								<h1><b>Our Satisfied Clients</b></h1>
							</div>
							<div class="section-bottom">
								<div class="text"><p>some of our great clients and their review</p></div>
							</div>
						</div>
						<div class="testimonial-inner">
							<div class="testimonial-slider">
								
							<?php
								$skills = vc_param_group_parse_atts($satisfied_client_group);
								foreach ($skills as $mr_media) :
								$groups = wp_get_attachment_url($mr_media['bg_image']);
							 ?>
								<!-- Single Testimonial -->
								<div class="single-slider">
									<p><?php echo $mr_media['content_area']?></p>	
									<!-- Client Info -->
									<div class="t-info">
										<div class="t-left">
											<div class="client-head"><img src="<?php echo $groups; ?>"></div>
											<h2><?php echo $mr_media['name']?><span><?php echo $mr_media['designation']?></span></h2>
										</div>
										<div class="t-right">
											<div class="quote"><i class="fa fa-quote-right"></i></div>
										</div>
									</div>
								</div>
								<!-- / End Single Testimonial -->
								<?php endforeach; ?>
								
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!--/ End Testimonials -->
		

<?php
return ob_get_clean();
}

add_action( 'vc_before_init', 'satisfied_client_group_feeds_elmentors' );
function satisfied_client_group_feeds_elmentors() {
 vc_map( array(
  "name" => __( "Satisfied Clients Testimonials", "bizwheel" ),
  "base" => "satisfied",
  "category" => __( "Bizwheel", "bizwheel"),
  "params" => array(
    array(
    'type' => 'param_group',
    'param_name' => 'satisfied_client_group',
// Note params is mapped inside param-group:
'params' => array(

array(
 "type" => "textarea",
 "heading" => __( "Content", "bizwheel" ),
 "param_name" => "content_area",
),

array(
 "type" => "textfield",
 "heading" => __( "Name", "bizwheel" ),
 "param_name" => "name",
),

array(
 "type" => "textfield",
 "heading" => __( "Designation", "bizwheel" ),
 "param_name" => "designation",
),
array(
 "type" => "attach_image",
 "heading" => __( "Section Background Image Upload", "bizwheel" ),
 "param_name" => "bg_image",
),

)            )
)
) );
}

?>








