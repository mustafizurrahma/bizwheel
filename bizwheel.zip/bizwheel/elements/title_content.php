<?php
add_shortcode('title','title_section_function');
function title_section_function($something){
$result = shortcode_atts(array(
        'degination' => '',
		'title' => '',
        'description' => '',
        'content' => '',
),$something);
extract($result);
ob_start();
?>


		<!-- Services -->
		<section class="services">
			<div class="container">
				<div class="row">
					<div class="col-12">
						<div class="section-title style2 text-center">
							<div class="section-top">
								<h1><span><?php echo esc_html($degination);?></span><b><?php echo esc_html($title);?></b></h1><h4><?php echo esc_html($description);?></h4>
							</div>
							<div class="section-bottom">
								<div class="text-style-two">
									<p><?php echo esc_html($content);?></p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!--/ End Services -->
		


<?php
return ob_get_clean();
}

add_action( 'vc_before_init', 'title_section_elmentors' );
function title_section_elmentors() {
 vc_map( array(
  "name" => __( "Title & Description Left Side", "bizwheel" ),
  "base" => "title",
  "category" => __( "Bizwheel", "bizwheel"),

  "params" => array(
 array(
  "type" => "textfield",
  "heading" => __( "Section Desination", "bizwheel" ),
  "param_name" => "degination",
),
 array(
  "type" => "textfield",
  "heading" => __( "Section title", "bizwheel" ),
  "param_name" => "title",
),
 array(
  "type" => "textfield",
  "heading" => __( "Description", "bizwheel" ),
  "param_name" => "description",
),
  )
 ) );
}

?>
