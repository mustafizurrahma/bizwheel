<?php
add_shortcode('add_section','team_section_function');
function team_section_function($something){
$result = shortcode_atts(array(
        'title' => '',
        'descp' => '',
		'button_name' => '',
        'url' => '',
),$something);
extract($result);
ob_start();
?>


		<!-- Call To Action -->
		<section class="call-action overlay" style="background-image:url('https://via.placeholder.com/1500x300')">
			<div class="container">
				<div class="row">
					<div class="col-lg-9 col-12">
						<div class="call-inner">
							<h2><?php echo esc_html($title);?></h2>
							<p><?php echo esc_html($descp);?></p>
						</div>
					</div>
					<div class="col-lg-3 col-12">
						<div class="button">
							<a href="<?php echo esc_html($url);?>" class="bizwheel-btn"><?php echo esc_html($button_name);?></a>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!--/ End Call to action -->

<?php
return ob_get_clean();
}

add_action( 'vc_before_init', 'team_small_section_elmentors' );
function team_small_section_elmentors() {
 vc_map( array(
  "name" => __( "Add Section", "bizwheel" ),
  "base" => "add_section",
  "category" => __( "Bizwheel", "bizwheel"),

  "params" => array(

array(
 "type" => "textfield",
 "heading" => __( "Title", "bizwheel" ),
 "param_name" => "title",
),
array(
 "type" => "textfield",
 "heading" => __( "Description", "bizwheel" ),
 "param_name" => "descp",
),
array(
 "type" => "textfield",
 "heading" => __( "Button Name Type Here", "bizwheel" ),
 "param_name" => "button_name",
),
array(
 "type" => "textfield",
 "heading" => __( "Button URL Here", "bizwheel" ),
 "param_name" => "url",
),

  )
 ) );
}

?>
