<?php
/*
plugin name:Bizwheel Theme Helper
version:1.0.0
author:Mustafizur Rahman
description:Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ..
*/

require dirname(__FILE__).'/elements/service.php';
require dirname(__FILE__).'/elements/add_section.php';
require dirname(__FILE__).'/elements/service_provide.php';
require dirname(__FILE__).'/elements/title_content.php';
require dirname(__FILE__).'/elements/satisfied_clients.php';
require dirname(__FILE__).'/elements/contact.php';
require dirname(__FILE__).'/elements/blog.php';
require dirname(__FILE__).'/elements/skills.php';
require dirname(__FILE__).'/elements/center_title.php';
require dirname(__FILE__).'/elements/blog_post.php';
require dirname(__FILE__).'/elements/our_partner.php';









